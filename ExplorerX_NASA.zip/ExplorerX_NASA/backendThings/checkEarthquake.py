import requests

# API endpoint
url = "https://earthquake.usgs.gov/fdsnws/event/1/query"

# Parameters for the API request
params = {
    "format": "geojson",
    "starttime": "2023-10-08",
    "endtime": "2023-10-09",
    "latitude": 37.8951,
    "longitude": 73.8062,
    "maxradiuskm": 100,
}

# Make the API request
response = requests.get(url, params=params)

# Parse the JSON response
data = response.json()

# Check for active earthquakes in the region
active_earthquakes = [event for event in data["features"] if event["properties"]["status"] == "reviewed"]

if active_earthquakes:
    print("There are active earthquakes in the region.")
    for earthquake in active_earthquakes:
        properties = earthquake['properties']
        print(f"Magnitude: {properties['mag']}, Location: {properties['place']}\n")
        # for key, value in properties.items():
        #     print(f"{key}: {value}")
else:
    print("No active earthquakes in the region.")