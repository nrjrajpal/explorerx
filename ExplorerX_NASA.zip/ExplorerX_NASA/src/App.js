import React from "react";
import { BrowserRouter as Router,Routes, Route } from "react-router-dom";
import Desktop1 from "./components/Desktop-1";
import Desktop3 from "./components/Desktop-3";
// Replace with the actual import for Desktop-3 component

function App() {
  return (
    <Router>
      <div>
        
     
      <Routes>
        <Route path="/desktop-3" element={<Desktop3 />} />
        <Route path="/" element={<Desktop1 />} />
        </Routes>
        </div>
    </Router>
  );
}

export default App;
