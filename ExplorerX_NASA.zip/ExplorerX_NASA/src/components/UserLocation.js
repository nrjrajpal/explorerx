import React, { useEffect, useState } from 'react';
import debounce from 'lodash/debounce';

const UserLocation = () => {
  const [city, setCity] = useState(null);

  useEffect(() => {
    const getLocation = () => {
      if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(
          async (position) => {
            const latitude = position.coords.latitude;
            const longitude = position.coords.longitude;

            try {
              // Perform reverse geocoding using Nominatim service
              const response = await fetch(
                `https://nominatim.openstreetmap.org/reverse?format=json&lat=${latitude}&lon=${longitude}`
              );

              if (response.ok) {
                const data = await response.json();
                const cityComponent = data.address.city || data.address.town;

                if (cityComponent) {
                  setCity(`${cityComponent}`);
                } else {
                  setCity('City not found in location data.');
                }
              } else {
                setCity('Location not found. Coordinates may be in a remote area.');
              }
            } catch (error) {
              setCity(`Error getting location: ${error.message}`);
            }
          },
          (error) => {
            if (error.code === error.PERMISSION_DENIED) {
              setCity('Permission to access location was denied.');
            } else {
              setCity(`Error getting location: ${error.message}`);
            }
          }
        );
      } else {
        setCity('Geolocation is not supported by your browser');
      }
    };

    // Debounce the getLocation function to limit the rate of requests
    const debouncedGetLocation = debounce(getLocation, 1000);

    debouncedGetLocation(); // Trigger initial request

    return () => {
      // Cleanup function to cancel pending requests (if any)
      debouncedGetLocation.cancel();
    };
  }, []);

  return (
    <div>
      
      <p id="city">{city}</p>
    </div>
  );
};

export default UserLocation;
