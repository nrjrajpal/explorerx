import React from "react";
import "./Desktop-3.css";
import "./global-1.css"
const Desktop3 = () => {
  return (
    <div className="desktop-3">
      <img className="geologist-1-icon" alt="" src="/geologist-1@2x.png" />
      <div className="welcome">welcome!</div>
      <div className="desktop-3-child" />
      <div className="login-or-signup">Login or Signup</div>
      <div className="desktop-3-item" />
      <div className="desktop-3-inner" />
      <div className="rectangle-div" />
      <div className="continue">Continue</div>
    </div>
  );
};

export default Desktop3;
