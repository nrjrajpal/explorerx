import React from "react";
import { Link } from "react-router-dom"; // Import Link from react-router-dom
import "./Desktop1.css";
import "./global.css";
import UserLocation from "./UserLocation";
import { GrLocation } from "react-icons/gr";

const Desktop1 = () => {
  

  return (
    <div className="desktop-1">
     <div className="gg">
     <GrLocation />
     </div>


      <div className="location">
      
        <UserLocation />
      </div>
      <section className="desktop-1-child" />
      <Link to="./Desktop-3" className="are-you-a">
        Are You a Geologist? Click here!
      </Link>
      <div className="earthquake-is-detected-container">
        <p className="earthquake-is-detected">{`Earthquake is detected `}</p>
        <p className="earthquake-is-detected">in this area!</p>
      </div>
      <div className="do-follow-the-container">
        <p className="earthquake-is-detected">{`Do follow the guidelines `}</p>
        <p className="earthquake-is-detected">for Safety purpose:</p>
      </div>
      <div className="desktop-1-item" />
      <div
        className="need-assistance-talk-container">
    
        <p className="earthquake-is-detected">need Assistance?</p>
        <p className="talk-to-an">Talk to an AI</p>
      </div>
    </div>
  );
};

export default Desktop1;
